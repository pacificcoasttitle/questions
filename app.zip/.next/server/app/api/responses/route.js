var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/responses/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__bf493a82._.js")
R.c("server/chunks/d2731_questions__next-internal_server_app_api_responses_route_actions_08f18fb1.js")
R.m(79771)
module.exports=R.m(79771).exports
