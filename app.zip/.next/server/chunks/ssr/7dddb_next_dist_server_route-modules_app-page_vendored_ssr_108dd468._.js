module.exports=[27510,(a,b,c)=>{"use strict";b.exports=a.r(98236).vendored["react-ssr"].ReactJsxRuntime},42937,(a,b,c)=>{"use strict";b.exports=a.r(98236).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=7dddb_next_dist_server_route-modules_app-page_vendored_ssr_108dd468._.js.map