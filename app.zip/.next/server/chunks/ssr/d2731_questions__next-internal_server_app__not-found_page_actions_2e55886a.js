module.exports=[37807,(a,b,c)=>{}];

//# sourceMappingURL=d2731_questions__next-internal_server_app__not-found_page_actions_2e55886a.js.map