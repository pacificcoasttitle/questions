module.exports=[67729,(a,b,c)=>{}];

//# sourceMappingURL=d2731_questions__next-internal_server_app__global-error_page_actions_bb149ced.js.map