module.exports=[72639,(e,o,d)=>{}];

//# sourceMappingURL=d2731_questions__next-internal_server_app_api_responses_route_actions_08f18fb1.js.map