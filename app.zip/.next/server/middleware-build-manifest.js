globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4490ef0d8346f9c2.js",
    "static/chunks/91f2326f896b07c0.js",
    "static/chunks/ade30b14e72e9e2f.js",
    "static/chunks/0621c7247905794e.js",
    "static/chunks/turbopack-604fdb7963a829ab.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];