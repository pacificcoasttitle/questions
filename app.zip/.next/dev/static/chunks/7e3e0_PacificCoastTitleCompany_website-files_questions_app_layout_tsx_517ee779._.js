(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__6a7649ce._.css",
  "static/chunks/7dddb_c4b01dea._.js"
],
    source: "dynamic"
});
