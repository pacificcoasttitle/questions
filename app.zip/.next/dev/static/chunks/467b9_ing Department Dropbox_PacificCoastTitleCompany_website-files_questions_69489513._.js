(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: 'bg-primary text-primary-foreground hover:bg-primary/90',
            destructive: 'bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
            outline: 'border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50',
            secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
            ghost: 'hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50',
            link: 'text-primary underline-offset-4 hover:underline'
        },
        size: {
            default: 'h-9 px-4 py-2 has-[>svg]:px-3',
            sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5',
            lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
            icon: 'size-9',
            'icon-sm': 'size-8',
            'icon-lg': 'size-10'
        }
    },
    defaultVariants: {
        variant: 'default',
        size: 'default'
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/button.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardAction",
    ()=>CardAction,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/utils.ts [app-client] (ecmascript)");
;
;
function Card({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Card;
function CardHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c1 = CardHeader;
function CardTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('leading-none font-semibold', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c2 = CardTitle;
function CardDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-muted-foreground text-sm', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_c3 = CardDescription;
function CardAction({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-action",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('col-start-2 row-span-2 row-start-1 self-start justify-self-end', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_c4 = CardAction;
function CardContent({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('px-6', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_c5 = CardContent;
function CardFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center px-6 [.border-t]:pt-6', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, this);
}
_c6 = CardFooter;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6;
__turbopack_context__.k.register(_c, "Card");
__turbopack_context__.k.register(_c1, "CardHeader");
__turbopack_context__.k.register(_c2, "CardTitle");
__turbopack_context__.k.register(_c3, "CardDescription");
__turbopack_context__.k.register(_c4, "CardAction");
__turbopack_context__.k.register(_c5, "CardContent");
__turbopack_context__.k.register(_c6, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/utils.ts [app-client] (ecmascript)");
;
;
function Input({ className, type, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm', 'focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]', 'aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/input.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Input;
;
var _c;
__turbopack_context__.k.register(_c, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
function Label({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "label",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/label.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Label;
;
var _c;
__turbopack_context__.k.register(_c, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/alert.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Alert",
    ()=>Alert,
    "AlertDescription",
    ()=>AlertDescription,
    "AlertTitle",
    ()=>AlertTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const alertVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])('relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current', {
    variants: {
        variant: {
            default: 'bg-card text-card-foreground',
            destructive: 'text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90'
        }
    },
    defaultVariants: {
        variant: 'default'
    }
});
function Alert({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(alertVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/alert.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_c = Alert;
function AlertTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('col-start-2 line-clamp-1 min-h-4 font-medium tracking-tight', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/alert.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_c1 = AlertTitle;
function AlertDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/alert.tsx",
        lineNumber: 55,
        columnNumber: 5
    }, this);
}
_c2 = AlertDescription;
;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Alert");
__turbopack_context__.k.register(_c1, "AlertTitle");
__turbopack_context__.k.register(_c2, "AlertDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AssessmentWizard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/components/ui/alert.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const TOOL_STEPS = [
    {
        toolKey: "title-profile",
        toolName: "Title Profile",
        questions: [
            {
                id: "q1",
                text: "Do you know how to access Title Profile?"
            },
            {
                id: "q2",
                text: "Do you know how to set up clients to receive profiles or alerts?"
            },
            {
                id: "q3",
                text: "Can you run property profiles?"
            },
            {
                id: "q4",
                text: "Can you explain profile sections to a client?"
            },
            {
                id: "q5",
                text: "Can you search by APN, owner, or address?"
            }
        ]
    },
    {
        toolKey: "title-toolbox",
        toolName: "Title Tool Box",
        questions: [
            {
                id: "q1",
                text: "Know how to log in / access"
            },
            {
                id: "q2",
                text: "Know how to create a client farm"
            },
            {
                id: "q3",
                text: "Know how to set up client saved searches"
            },
            {
                id: "q4",
                text: "Can create farm lists"
            },
            {
                id: "q5",
                text: "Can build targeted lists (NOD, equity, absentee, etc.)"
            },
            {
                id: "q6",
                text: "Can export lists"
            }
        ]
    },
    {
        toolKey: "pacific-agent-one",
        toolName: "Pacific Agent ONE",
        questions: [
            {
                id: "q1",
                text: "Know how to access & install the app"
            },
            {
                id: "q2",
                text: "Know how to add clients into the app"
            },
            {
                id: "q3",
                text: "Know how to brand the app with their info"
            },
            {
                id: "q4",
                text: "Can generate seller net sheets & buyer estimates"
            },
            {
                id: "q5",
                text: "Can share branded live net sheets with clients"
            }
        ]
    },
    {
        toolKey: "pct-smart-direct",
        toolName: "PCT Smart Direct",
        questions: [
            {
                id: "q1",
                text: "Know how to access Smart Direct"
            },
            {
                id: "q2",
                text: "Can set up new client campaigns"
            },
            {
                id: "q3",
                text: "Can create mailing lists"
            },
            {
                id: "q4",
                text: "Can generate postcards"
            },
            {
                id: "q5",
                text: "Can filter properly (distress, equity, absentee, etc.)"
            }
        ]
    },
    {
        toolKey: "pct-website",
        toolName: "PCT Website",
        questions: [
            {
                id: "q1",
                text: "Know how to navigate the website"
            },
            {
                id: "q2",
                text: "Know how to set up clients with tools or resources"
            },
            {
                id: "q3",
                text: "Can find all available resources"
            },
            {
                id: "q4",
                text: "Can guide clients through the site"
            }
        ]
    },
    {
        toolKey: "trainings",
        toolName: "Trainings Offered by PCT",
        questions: [
            {
                id: "q1",
                text: "Know what trainings are available"
            },
            {
                id: "q2",
                text: "Know how to access training schedules"
            },
            {
                id: "q3",
                text: "Know how to enroll clients in trainings"
            },
            {
                id: "q4",
                text: "Know how to leverage training content"
            }
        ]
    },
    {
        toolKey: "sales-dashboard",
        toolName: "Sales Dashboard",
        questions: [
            {
                id: "q1",
                text: "Do you know how to access your PCT Sales Dashboard?"
            },
            {
                id: "q2",
                text: "Do you know how to read your numbers?"
            },
            {
                id: "q3",
                text: "Are you checking weekly? (Sales Units, Refi Units, Revenue, Pipeline, Assigned Accounts, Activity Metrics)"
            },
            {
                id: "q4",
                text: "Do you know how to track: Personal goals, Monthly targets, Year-over-year comparison, Daily activity requirements"
            }
        ]
    }
];
const CONFIDENCE_CATEGORIES = [
    {
        key: "awareness",
        label: "Awareness"
    },
    {
        key: "access",
        label: "Know How to Access"
    },
    {
        key: "setup",
        label: "Know How to Setup"
    },
    {
        key: "usage",
        label: "Usage"
    },
    {
        key: "needTraining",
        label: "Need Training"
    }
];
function AssessmentWizard() {
    _s();
    const [userName, setUserName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [userEmail, setUserEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [responses, setResponses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "title-profile": {},
        "title-toolbox": {},
        "pacific-agent-one": {},
        "pct-smart-direct": {},
        "pct-website": {},
        trainings: {},
        "sales-dashboard": {}
    });
    const [confidenceRatings, setConfidenceRatings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [submitError, setSubmitError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isSuccess, setIsSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scores, setScores] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const totalSteps = 9 // 0=intro, 1-7=tools, 8=confidence, 9=results
    ;
    const handleResponseChange = (toolKey, questionId, value)=>{
        setResponses((prev)=>({
                ...prev,
                [toolKey]: {
                    ...prev[toolKey],
                    [questionId]: value
                }
            }));
    };
    const handleConfidenceChange = (toolKey, category, rating)=>{
        setConfidenceRatings((prev)=>({
                ...prev,
                [toolKey]: {
                    ...prev[toolKey],
                    [category]: rating
                }
            }));
    };
    const isStepComplete = ()=>{
        if (currentStep === 0) {
            return userName.trim() !== "" && userEmail.trim() !== "" && userEmail.includes("@");
        }
        if (currentStep >= 1 && currentStep <= 7) {
            const toolStep = TOOL_STEPS[currentStep - 1];
            const toolResponses = responses[toolStep.toolKey];
            return toolStep.questions.every((q)=>toolResponses[q.id] !== undefined);
        }
        if (currentStep === 8) {
            return TOOL_STEPS.every((tool)=>{
                const ratings = confidenceRatings[tool.toolKey];
                return ratings && CONFIDENCE_CATEGORIES.every((cat)=>ratings[cat.key] > 0);
            });
        }
        return true;
    };
    const handleNext = ()=>{
        if (currentStep < totalSteps) {
            setCurrentStep(currentStep + 1);
        }
    };
    const handlePrevious = ()=>{
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };
    const handleSubmit = async ()=>{
        setIsSubmitting(true);
        setSubmitError(null);
        try {
            const res = await fetch("/api/responses", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    respondentName: userName,
                    respondentEmail: userEmail,
                    responses,
                    confidenceRatings
                })
            });
            const data = await res.json();
            if (data.success) {
                setIsSuccess(true);
                setScores(data.scores);
                setCurrentStep(9);
            } else {
                setSubmitError(data.error || "Submission failed");
            }
        } catch  {
            setSubmitError("Failed to submit. Please try again.");
        } finally{
            setIsSubmitting(false);
        }
    };
    const calculatePreviewScores = ()=>{
        let totalYes = 0;
        let totalQuestions = 0;
        TOOL_STEPS.forEach((tool)=>{
            tool.questions.forEach((q)=>{
                totalQuestions++;
                if (responses[tool.toolKey][q.id] === true) {
                    totalYes++;
                }
            });
        });
        let totalConfidence = 0;
        let ratingCount = 0;
        Object.values(confidenceRatings).forEach((ratings)=>{
            Object.values(ratings).forEach((rating)=>{
                totalConfidence += rating;
                ratingCount++;
            });
        });
        const capabilityScore = totalYes;
        const capabilityPercent = totalQuestions > 0 ? Math.round(totalYes / totalQuestions * 100) : 0;
        const confidenceScore = ratingCount > 0 ? (totalConfidence / ratingCount).toFixed(1) : "0.0";
        return {
            capabilityScore,
            capabilityPercent,
            confidenceScore,
            totalQuestions
        };
    };
    const renderStep = ()=>{
        // Step 0: User Information
        if (currentStep === 0) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "border-0 shadow-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "text-2xl text-balance",
                                children: "Welcome to the Sales Tool Competency Assessment"
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 259,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                className: "text-base",
                                children: "This assessment will help us understand your familiarity with Pacific Coast Title's sales tools and identify areas where additional training may be beneficial."
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 260,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 258,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "name",
                                        children: "Full Name *"
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 267,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "name",
                                        type: "text",
                                        placeholder: "Enter your name",
                                        value: userName,
                                        onChange: (e)=>setUserName(e.target.value),
                                        className: "h-11"
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 268,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 266,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "email",
                                        children: "Email Address *"
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 278,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "email",
                                        type: "email",
                                        placeholder: "your.email@example.com",
                                        value: userEmail,
                                        onChange: (e)=>setUserEmail(e.target.value),
                                        className: "h-11"
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 279,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 277,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 265,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                lineNumber: 257,
                columnNumber: 9
            }, this);
        }
        // Steps 1-7: Tool Questions
        if (currentStep >= 1 && currentStep <= 7) {
            const toolStep = TOOL_STEPS[currentStep - 1];
            const toolResponses = responses[toolStep.toolKey];
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "border-0 shadow-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "text-2xl",
                                children: toolStep.toolName
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 301,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                children: [
                                    "Please answer the following questions about your experience with ",
                                    toolStep.toolName,
                                    "."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 300,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: toolStep.questions.map((question, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-3 pb-4 border-b last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                            className: "text-base font-medium leading-relaxed",
                                            children: [
                                                index + 1,
                                                ". ",
                                                question.text
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 310,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                    type: "button",
                                                    variant: toolResponses[question.id] === true ? "default" : "outline",
                                                    className: "flex-1 h-11",
                                                    onClick: ()=>handleResponseChange(toolStep.toolKey, question.id, true),
                                                    children: "Yes"
                                                }, void 0, false, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 314,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                    type: "button",
                                                    variant: toolResponses[question.id] === false ? "default" : "outline",
                                                    className: "flex-1 h-11",
                                                    onClick: ()=>handleResponseChange(toolStep.toolKey, question.id, false),
                                                    children: "No"
                                                }, void 0, false, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 322,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 313,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, question.id, true, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 309,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 307,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 306,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                lineNumber: 299,
                columnNumber: 9
            }, this);
        }
        // Step 8: Confidence Ratings
        if (currentStep === 8) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "border-0 shadow-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "text-2xl",
                                children: "Confidence Level Assessment"
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 344,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                children: "Rate your confidence level for each tool across the following areas. Use a scale of 1 (No Knowledge) to 5 (Expert Level)."
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 345,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 343,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-8",
                            children: TOOL_STEPS.map((tool)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-semibold text-lg",
                                            children: tool.toolName
                                        }, void 0, false, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 354,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: CONFIDENCE_CATEGORIES.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                            className: "text-sm",
                                                            children: category.label
                                                        }, void 0, false, {
                                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                            lineNumber: 358,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                1,
                                                                2,
                                                                3,
                                                                4,
                                                                5
                                                            ].map((rating)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                    type: "button",
                                                                    variant: confidenceRatings[tool.toolKey]?.[category.key] === rating ? "default" : "outline",
                                                                    className: "flex-1 h-11 font-semibold",
                                                                    onClick: ()=>handleConfidenceChange(tool.toolKey, category.key, rating),
                                                                    children: rating
                                                                }, rating, false, {
                                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                                    lineNumber: 361,
                                                                    columnNumber: 29
                                                                }, this))
                                                        }, void 0, false, {
                                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                            lineNumber: 359,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, category.key, true, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 357,
                                                    columnNumber: 23
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 355,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, tool.toolKey, true, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 353,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 351,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 350,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                lineNumber: 342,
                columnNumber: 9
            }, this);
        }
        // Step 9: Review & Submit
        if (currentStep === 9) {
            if (isSuccess && scores) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                    className: "border-0 shadow-none",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3 mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-12 w-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                                className: "h-6 w-6 text-green-600 dark:text-green-400"
                                            }, void 0, false, {
                                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                lineNumber: 397,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 396,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                            className: "text-2xl",
                                            children: [
                                                "Thank you, ",
                                                userName,
                                                "!"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 399,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 395,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                    className: "text-base",
                                    children: "Your responses have been successfully saved."
                                }, void 0, false, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 401,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 394,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-4 md:grid-cols-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                                        children: "Capability Score"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                        lineNumber: 407,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                        className: "text-3xl",
                                                        children: [
                                                            scores.capability,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                        lineNumber: 408,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                lineNumber: 406,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 405,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                                        children: "Average Confidence"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                        lineNumber: 413,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                        className: "text-3xl",
                                                        children: [
                                                            scores.confidence,
                                                            "/5"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                        lineNumber: 414,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                lineNumber: 412,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 411,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 404,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Alert"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDescription"], {
                                        className: "text-base",
                                        children: "A member of our training team will review your responses and reach out with personalized recommendations for improving your tool proficiency."
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 419,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 418,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 403,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                    lineNumber: 393,
                    columnNumber: 11
                }, this);
            }
            const previewScores = calculatePreviewScores();
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "border-0 shadow-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "text-2xl",
                                children: "Review Your Assessment"
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 433,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                children: "Review your scores below, then submit your assessment."
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 434,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 432,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid gap-4 md:grid-cols-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                                    children: "Capability Score"
                                                }, void 0, false, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 440,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                    className: "text-3xl",
                                                    children: [
                                                        previewScores.capabilityScore,
                                                        "/",
                                                        previewScores.totalQuestions,
                                                        " (",
                                                        previewScores.capabilityPercent,
                                                        "%)"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 441,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 439,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 438,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                                    children: "Average Confidence"
                                                }, void 0, false, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 448,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                    className: "text-3xl",
                                                    children: [
                                                        previewScores.confidenceScore,
                                                        "/5"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                                    lineNumber: 449,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 447,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                        lineNumber: 446,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 437,
                                columnNumber: 13
                            }, this),
                            submitError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Alert"], {
                                variant: "destructive",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDescription"], {
                                    children: submitError
                                }, void 0, false, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 455,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 454,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleSubmit,
                                disabled: isSubmitting,
                                size: "lg",
                                className: "w-full h-12 text-base",
                                children: isSubmitting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                            className: "mr-2 h-5 w-5 animate-spin"
                                        }, void 0, false, {
                                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                            lineNumber: 461,
                                            columnNumber: 19
                                        }, this),
                                        "Submitting..."
                                    ]
                                }, void 0, true) : "Submit Assessment"
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 458,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 436,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                lineNumber: 431,
                columnNumber: 9
            }, this);
        }
        return null;
    };
    const progress = currentStep / totalSteps * 100;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-slate-50 via-stone-50/50 to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-900",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 py-8 max-w-4xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-8 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-3xl md:text-4xl font-bold text-slate-800 dark:text-slate-100 mb-2 text-balance",
                            children: "Pacific Coast Title"
                        }, void 0, false, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 483,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-slate-600 dark:text-slate-300 text-lg",
                            children: "Sales Tool Competency Assessment"
                        }, void 0, false, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 486,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                    lineNumber: 482,
                    columnNumber: 9
                }, this),
                currentStep < 9 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center mb-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm font-medium text-slate-700 dark:text-slate-300",
                                    children: [
                                        "Step ",
                                        currentStep + 1,
                                        " of ",
                                        totalSteps
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 493,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm font-medium text-slate-700 dark:text-slate-300",
                                    children: [
                                        Math.round(progress),
                                        "%"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                    lineNumber: 496,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 492,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-full bg-gradient-to-r from-slate-500 via-slate-400 to-stone-400 dark:from-slate-500 dark:via-slate-400 dark:to-stone-500 transition-all duration-300 ease-out",
                                style: {
                                    width: `${progress}%`
                                }
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 499,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                            lineNumber: 498,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                    lineNumber: 491,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: renderStep()
                }, void 0, false, {
                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                    lineNumber: 508,
                    columnNumber: 9
                }, this),
                !isSuccess && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                    className: "border-0 shadow-sm",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex justify-between gap-4 pt-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                onClick: handlePrevious,
                                disabled: currentStep === 0 || isSubmitting,
                                size: "lg",
                                className: "flex-1 h-12 bg-transparent",
                                children: "Previous"
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 514,
                                columnNumber: 15
                            }, this),
                            currentStep < 9 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleNext,
                                disabled: !isStepComplete() || isSubmitting,
                                size: "lg",
                                className: "flex-1 h-12",
                                children: currentStep === 8 ? "Review & Submit" : "Next"
                            }, void 0, false, {
                                fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                                lineNumber: 524,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                        lineNumber: 513,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
                    lineNumber: 512,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
            lineNumber: 480,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/page.tsx",
        lineNumber: 479,
        columnNumber: 5
    }, this);
}
_s(AssessmentWizard, "hlXeiSUklMGm7ZvyMDemFEXeM88=");
_c = AssessmentWizard;
var _c;
__turbopack_context__.k.register(_c, "AssessmentWizard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=467b9_ing%20Department%20Dropbox_PacificCoastTitleCompany_website-files_questions_69489513._.js.map