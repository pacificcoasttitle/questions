var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/responses/route.js")
R.c("server/chunks/7dddb_next_964c4688._.js")
R.c("server/chunks/[root-of-the-server]__cd04b3d0._.js")
R.c("server/chunks/d2731_questions__next-internal_server_app_api_responses_route_actions_08f18fb1.js")
R.m("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/api/responses/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/api/responses/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
