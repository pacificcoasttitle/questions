module.exports = [
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/.next-internal/server/app/api/responses/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=d2731_questions__next-internal_server_app_api_responses_route_actions_08f18fb1.js.map