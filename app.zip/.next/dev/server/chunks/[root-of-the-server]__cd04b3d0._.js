module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/pg [external] (pg, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("pg");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/db.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "query",
    ()=>query
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/pg [external] (pg, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
const pool = new __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__["Pool"]({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});
async function query(text, params) {
    const client = await pool.connect();
    try {
        return await client.query(text, params);
    } finally{
        client.release();
    }
}
const __TURBOPACK__default__export__ = pool;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/app/api/responses/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Marketing Department Dropbox/PacificCoastTitleCompany/website-files/questions/lib/db.ts [app-route] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
const TOOL_MAP = {
    'title-profile': {
        prefix: 'tp',
        questions: 5
    },
    'title-toolbox': {
        prefix: 'ttb',
        questions: 6
    },
    'pacific-agent-one': {
        prefix: 'pao',
        questions: 5
    },
    'pct-smart-direct': {
        prefix: 'psd',
        questions: 5
    },
    'pct-website': {
        prefix: 'pw',
        questions: 4
    },
    'trainings': {
        prefix: 'tr',
        questions: 4
    },
    'sales-dashboard': {
        prefix: 'sd',
        questions: 4
    }
};
async function POST(request) {
    try {
        const { respondentName, respondentEmail, responses, confidenceRatings } = await request.json();
        if (!respondentName || !respondentEmail) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Name and email required'
            }, {
                status: 400
            });
        }
        const columns = [
            'respondent_name',
            'respondent_email'
        ];
        const values = [
            respondentName,
            respondentEmail
        ];
        for (const [toolKey, config] of Object.entries(TOOL_MAP)){
            const toolResponses = responses[toolKey] || {};
            for(let i = 1; i <= config.questions; i++){
                columns.push(`${config.prefix}_q${i}`);
                values.push(toolResponses[`q${i}`] ?? null);
            }
        }
        for (const [toolKey, config] of Object.entries(TOOL_MAP)){
            const ratings = confidenceRatings[toolKey] || {};
            columns.push(`${config.prefix}_awareness`);
            values.push(ratings.awareness ?? null);
            columns.push(`${config.prefix}_access`);
            values.push(ratings.access ?? null);
            columns.push(`${config.prefix}_setup`);
            values.push(ratings.setup ?? null);
            columns.push(`${config.prefix}_usage`);
            values.push(ratings.usage ?? null);
            columns.push(`${config.prefix}_need_training`);
            values.push(ratings.needTraining ?? null);
        }
        const allResponses = Object.values(responses).flatMap((t)=>Object.values(t));
        const yesCount = allResponses.filter((v)=>v === true).length;
        const capabilityScore = allResponses.length > 0 ? yesCount / 33 * 100 : 0;
        const allConfidence = Object.values(confidenceRatings).flatMap((t)=>Object.values(t));
        const avgConfidence = allConfidence.length > 0 ? allConfidence.reduce((a, b)=>a + b, 0) / allConfidence.length : 0;
        columns.push('capability_score', 'avg_confidence_score');
        values.push(capabilityScore.toFixed(2), avgConfidence.toFixed(2));
        const placeholders = values.map((_, i)=>`$${i + 1}`).join(', ');
        const sql = `INSERT INTO responses (${columns.join(', ')}) VALUES (${placeholders}) RETURNING id, submitted_at`;
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["query"])(sql, values);
        return __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            id: result.rows[0].id,
            submittedAt: result.rows[0].submitted_at,
            scores: {
                capability: Math.round(capabilityScore),
                capabilityRaw: `${yesCount}/33`,
                confidence: avgConfidence.toFixed(1)
            }
        });
    } catch (error) {
        console.error('Save error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to save'
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 100);
        const offset = parseInt(searchParams.get('offset') || '0');
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["query"])(`SELECT id, respondent_name, respondent_email, submitted_at, capability_score, avg_confidence_score FROM responses ORDER BY submitted_at DESC LIMIT $1 OFFSET $2`, [
            limit,
            offset
        ]);
        const count = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["query"])('SELECT COUNT(*) FROM responses');
        return __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            responses: result.rows,
            total: parseInt(count.rows[0].count)
        });
    } catch (error) {
        console.error('Fetch error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$Marketing__Department__Dropbox$2f$PacificCoastTitleCompany$2f$website$2d$files$2f$questions$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to fetch'
        }, {
            status: 500
        });
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__cd04b3d0._.js.map