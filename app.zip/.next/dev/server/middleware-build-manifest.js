globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/7dddb_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7341560f._.js",
    "static/chunks/7dddb_next_dist_compiled_react-dom_7d6df342._.js",
    "static/chunks/7dddb_next_dist_compiled_react-server-dom-turbopack_2782223b._.js",
    "static/chunks/7dddb_next_dist_compiled_next-devtools_index_e1ebf275.js",
    "static/chunks/7dddb_next_dist_compiled_7066afa1._.js",
    "static/chunks/7dddb_next_dist_client_b4cf7e3e._.js",
    "static/chunks/7dddb_next_dist_ce1fb6bf._.js",
    "static/chunks/7dddb_@swc_helpers_cjs_8282c88e._.js",
    "static/chunks/467b9_ing Department Dropbox_PacificCoastTitleCompany_website-files_questions_a0ff3932._.js",
    "static/chunks/4d4ff_ing Department Dropbox_PacificCoastTitleCompany_website-files_questions_336ee821._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];